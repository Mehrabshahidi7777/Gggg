<?php

use App\Http\Middleware\AdminMiddleware;
use App\Http\Middleware\EnsureOnlineCheckoutEnabled;
use App\Http\Middleware\RequireMobile;
use App\Models\Ad;
use App\Models\ServiceSubscription;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

$app = Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__ . '/../routes/web.php',
        commands: __DIR__ . '/../routes/console.php',
        health: '/up',
    )

    ->withMiddleware(function (Middleware $middleware): void {

        $middleware->alias([
            'admin' => AdminMiddleware::class,
            'checkout.enabled' => EnsureOnlineCheckoutEnabled::class,
            'require.mobile' => RequireMobile::class,
        ]);

        /*
        |--------------------------------------------------------------------------
        | SEP Payment Callback
        |--------------------------------------------------------------------------
        */

        $middleware->validateCsrfTokens(except: [
            'payments/sep/order',
            'payments/sep/service',
            'payments/sep/product',
        ]);
    })

    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })

    ->withSchedule(function (Schedule $schedule): void {

        /*
        |--------------------------------------------------------------------------
        | Subscription Expiration (service & product)
        |--------------------------------------------------------------------------
        |
        | هر ساعت:
        |
        | 1. اشتراک‌های منقضی‌شده را expired می‌کنیم.
        | 2. خدمات کاربر را suspend می‌کنیم.
        |
        */

        $schedule->call(function (): void {

            $now = now();

            /*
            | ⚠️ ردِ پا. صاحب سایت به دیتابیس دسترسی ندارد؛ بدون این خط
            | راهی نیست بفهمد اشتراکی تمام شده و آگهی‌هایش واقعاً تعلیق
            | شده‌اند. فقط وقتی کاری انجام شده می‌نویسد - این کار ساعتی
            | است و یک خطِ خالی در هر ساعت لاگ را بی‌مصرف می‌کرد. اینکه
            | اصلاً اجرا شده را cron.log نشان می‌دهد.
            */
            $expired = [];

            ServiceSubscription::query()
                ->where('status', 'active')
                ->whereNotNull('ends_at')
                ->where('ends_at', '<=', $now)
                ->chunkById(100, function ($subscriptions) use (&$expired): void {

                    foreach ($subscriptions as $subscription) {

                        $subscription->update([
                            'status' => 'expired',
                            'grace_until' => $subscription
                                ->ends_at
                                ->copy()
                                ->addMonths(6),
                        ]);

                        $suspended = Ad::query()
                            ->where('user_id', $subscription->user_id)
                            // این «service» هاردکد بود؛ چون همین جدول اشتراک
                            // حالا هم مال خدمت هم مال محصول است، باید دقیقاً
                            // همان نوعی که اشتراکش تمام شده تعلیق شود - نه
                            // همیشه service.
                            ->where('type', $subscription->type)
                            ->where('is_suspended', false)
                            ->update([
                                'is_suspended' => true,

                                /*
                                | شروع مهلت شش ماهه
                                | از پایان واقعی اشتراک است.
                                */
                                'suspended_at' => $subscription->ends_at,
                            ]);

                        $expired[$subscription->id] = $suspended;
                    }
                });

            if ($expired) {
                Log::channel('cron')->info('sazmat:expire-subscriptions', [
                    'اشتراک تمام‌شده' => count($expired),
                    'آگهی تعلیق‌شده' => array_sum($expired),
                    'شناسه‌ها' => array_keys($expired),
                ]);
            }

        })->name('sazmat:expire-subscriptions')->hourly();


        /*
        |--------------------------------------------------------------------------
        | Permanent Cleanup (service & product)
        |--------------------------------------------------------------------------
        |
        | بعد از شش ماه:
        |
        | - فایل تصاویر حذف می‌شود.
        | - رکورد تصاویر حذف می‌شود.
        | - خود خدمت حذف می‌شود.
        |
        */

        $schedule->call(function (): void {

            $cutoff = now()->subMonths(6);

            /*
            | ⚠️ این کار آگهی را برای همیشه پاک می‌کند. بدون ردِ پا،
            | پاک‌شدنِ یک آگهی از بیرون با گم‌شدنش یک شکل است.
            | فقط وقتی چیزی پاک شده می‌نویسد.
            */
            $deletedAds = [];

            Ad::query()
                ->with('images')
                // قبلاً اینجا where('type','service') هم بود؛ حذف شد چون
                // این پاک‌سازی باید بدون توجه به نوع آگهی، هر آگهیِ (خدمت
                // یا محصول) که ۶ ماه تعلیق مانده را شامل شود.
                ->where('is_suspended', true)
                ->whereNotNull('suspended_at')
                ->where('suspended_at', '<=', $cutoff)
                ->chunkById(100, function ($ads) use (&$deletedAds): void {

                    foreach ($ads as $ad) {

                        /*
                        |--------------------------------------------------------------------------
                        | Delete physical image files
                        |--------------------------------------------------------------------------
                        */

                        foreach ($ad->images as $image) {

                            if ($image->path) {
                                Storage::disk('public')->delete(
                                    $image->path
                                );
                            }
                        }

                        /*
                        |--------------------------------------------------------------------------
                        | Delete ad
                        |--------------------------------------------------------------------------
                        |
                        | ad_images به خاطر ON DELETE CASCADE
                        | از دیتابیس هم حذف می‌شوند.
                        |
                        */

                        $ad->delete();

                        $deletedAds[] = $ad->id;
                    }
                });


            /*
            |--------------------------------------------------------------------------
            | Delete old subscriptions
            |--------------------------------------------------------------------------
            */

            $deletedSubscriptions = ServiceSubscription::query()
                ->whereIn('status', [
                    'expired',
                    'suspended',
                ])
                ->whereNotNull('grace_until')
                ->where('grace_until', '<=', now())
                ->delete();

            if ($deletedAds || $deletedSubscriptions) {
                Log::channel('cron')->info('sazmat:purge-suspended', [
                    'آگهی پاک‌شده' => count($deletedAds),
                    'شناسه‌ی آگهی‌ها' => $deletedAds,
                    'اشتراک پاک‌شده' => $deletedSubscriptions,
                ]);
            }

        })->name('sazmat:purge-suspended')->hourly();


        /*
        |--------------------------------------------------------------------------
        | Nightly cleanup
        |--------------------------------------------------------------------------
        |
        | فایل‌های تصویرِ بی‌صاحب، پرداخت‌های نیمه‌کاره، OTPهای منقضی و
        | پیش‌نویس‌های رهاشده. جزئیات در CleanupCommand.
        |
        | چون کرون‌جاب هاست از قبل هر دقیقه schedule:run را صدا می‌زند،
        | این کار بدون هیچ تنظیم اضافه‌ای هر شب ساعت ۳ اجرا می‌شود.
        |
        */
        /*
        | ⚠️ call + Artisan::call، نه command().
        |
        | proc_open روی این هاست غیرفعال است. $schedule->command() برای
        | هر دستور یک پروسه‌ی جدا باز می‌کند و بدون proc_open همان‌جا
        | استثنا می‌دهد:
        |
        |   The Process class relies on proc_open, which is not
        |   available on your PHP installation.
        |
        | و بدترین بخشش این بود که در cron.log «DONE» چاپ می‌شد - چون
        | زمان‌بند خطا را می‌گیرد و در laravel.log می‌نویسد، ولی خروجیِ
        | خودش موفق به نظر می‌رسد. یعنی این دستور از روز اول هرگز اجرا
        | نشده بود و لاگ هم می‌گفت اجرا شده.
        |
        | نشانه‌اش همین بود: ۲۴ میلی‌ثانیه «اجرا»، و OTPهای مرداد که
        | هنوز در جدول بودند.
        |
        | Artisan::call همان دستور را داخل همین پروسه اجرا می‌کند، پس
        | نه به proc_open نیاز دارد نه به چیز دیگری. کارهای دیگرِ این
        | زمان‌بند (Callbackهای ساعتی) از اول هم بسته‌ای بودند و درست
        | کار می‌کردند - به همین دلیل کسی متوجه نشده بود.
        */
        $schedule->call(function (): void {
            Artisan::call('sazmat:cleanup');
        })
            ->name('sazmat:cleanup')
            ->dailyAt('03:00')
            ->withoutOverlapping();


        /*
        |--------------------------------------------------------------------------
        | Subscription renewal reminders
        |--------------------------------------------------------------------------
        |
        | ساعت ۱۰ صبح - نه نیمه‌شب - تا پیامک در زمانی برسد که گیرنده
        | بیدار است و می‌تواند همان لحظه اقدام کند.
        |
        */
        /* همان دلیل بالا: بدون proc_open، command() اجرا نمی‌شود. */
        $schedule->call(function (): void {
            Artisan::call('sazmat:subscription-reminders');
        })
            ->name('sazmat:subscription-reminders')
            ->dailyAt('10:00')
            ->withoutOverlapping();

    })

    ->create();


/*
|--------------------------------------------------------------------------
| Laravel Public Path
|--------------------------------------------------------------------------
|
| پروژه Laravel داخل zzz است و DocumentRoot روی public_html قرار دارد.
|
*/

$app->usePublicPath(
    dirname(__DIR__) . '/../public_html'
);

return $app;