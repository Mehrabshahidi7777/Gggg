<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use RuntimeException;

class AmootSmsService
{
    /*
    |--------------------------------------------------------------------------
    | کد یک‌بارمصرف ورود
    |--------------------------------------------------------------------------
    */
    public function sendOtp(string $mobile, string $code): void
    {
        $pattern = (int) config('services.amoot.pattern_code_id');

        if (! $pattern) {
            throw new RuntimeException('تنظیمات پیامک آموت کامل نشده است.');
        }

        $this->sendWithPattern($mobile, $pattern, $code);
    }

    /*
    |--------------------------------------------------------------------------
    | پیامک یادآوری تمدید اشتراک
    |--------------------------------------------------------------------------
    |
    | سامانه‌های پیامکی ایران معمولاً ارسال متن آزاد را فقط روی خط
    | خدماتی اجازه می‌دهند و در غیر این صورت باید «پترن» از قبل در پنل
    | تعریف و تأیید شده باشد.
    |
    | چون نمی‌دانیم پنل شما کدام حالت را دارد، هر دو پشتیبانی می‌شود:
    |
    |   اگر شناسه‌ی پترن در .env ست شده باشد → با پترن
    |   در غیر این صورت                      → متن ساده
    |
    | دو متغیر: نوع اشتراک، و وضعیت.
    |
    | ⚠️ متغیر دوم عمداً یک *عبارت* است، نه تعداد روز.
    |
    | اگر عدد بود، هر سه مرحله نمی‌توانستند از یک پترن استفاده کنند:
    | مرحله‌ی «تمام شد» پیامکِ «تا ۰ روز دیگر تمام می‌شود» می‌داد - هم
    | غلط، هم برعکسِ کاری که باید بکند. با عبارت، یک پترن هر سه مرحله
    | را درست می‌گوید و کاربر فقط یک شناسه در پنل می‌سازد:
    |
    |   «تا 7 روز دیگر تمام می‌شود»
    |   «فردا تمام می‌شود»
    |   «تمام شد؛ آگهی‌ها تعلیق شدند»
    |
    | ⚠️ نامِ کاربر عمداً در پیامک نیست.
    |
    | سقف یک صفحه‌ی پیامک فارسی ۷۰ کاراکتر است و از آن به بعد هزینه
    | دو برابر می‌شود. نامِ کاربری در این سایت هم انگلیسی است و تا ۵۰
    | حرف می‌تواند باشد - یعنی یک نام بلند، پیام را به سه صفحه
    | می‌برد. بدون نام، بدترین حالت ۶۵ کاراکتر است: همیشه یک صفحه.
    |
    | پیامک هم به شماره‌ی خودِ کاربر می‌رود و درباره‌ی اشتراک خودش
    | است، پس نام چیز زیادی اضافه نمی‌کرد.
    |
    */
    public function sendRenewalReminder(string $mobile, string $message, array $patternValues = []): void
    {
        $pattern = (int) config('services.amoot.pattern_renewal_id');

        /*
        | پیش از هر چیز، تنظیمات. بدون این، نبودِ توکن همان
        | RuntimeException را می‌دهد که پایین‌تر «پترن رد شد» تفسیر
        | می‌شود - و یک خط لاگِ گمراه‌کننده می‌سازد.
        */
        $this->credentials();

        if (! $pattern) {
            $this->sendText($mobile, $message);

            return;
        }

        /*
        |----------------------------------------------------------------------
        | اگر آموت پترن را نپذیرفت، متن ساده
        |----------------------------------------------------------------------
        |
        | ⚠️ یک پترن بین ساخته‌شدن و تأییدشدن، چند روز در حالت «در
        | انتظار بررسی» می‌ماند. در آن مدت شناسه‌اش وجود دارد ولی
        | ارسال با آن رد می‌شود.
        |
        | قبلاً نتیجه‌ی این حالت «هیچ پیامکی» بود: شناسه ست بود، پس
        | متن ساده هم امتحان نمی‌شد. یعنی گذاشتنِ شناسه در .env پیش
        | از تأیید، یادآوری‌ها را تا روز تأیید خاموش می‌کرد.
        |
        | حالا متن ساده پشتوانه است. روی خط خدماتی متن آزاد مجاز
        | است، پس پیامک می‌رسد - فقط بدون قالبِ پترن.
        |
        | ⚠️ و فقط وقتی که آموت *جواب داده و رد کرده* - نه وقتی
        | ارتباط قطع شده.
        |
        | تفاوتش مهم است: پاسخِ رد یعنی مطمئنیم چیزی نرفته، پس ارسال
        | دوباره بی‌خطر است. ولی قطعیِ ارتباط یا تایم‌اوت یعنی
        | نمی‌دانیم درخواست رسیده یا نه؛ آنجا تلاش دوباره می‌تواند
        | دو پیامک بفرستد. پس ConnectionException رد می‌شود و بالا
        | می‌رود تا دستور فردا دوباره امتحان کند.
        |
        | خطا در لاگ می‌نشیند، وگرنه یک پترنِ همیشه‌خراب بی‌صدا پشت
        | متن ساده پنهان می‌ماند.
        */
        try {
            $this->sendWithPattern($mobile, $pattern, $this->joinValues($patternValues));

            return;

        } catch (RuntimeException $e) {

            Log::channel('cron')->warning('amoot pattern rejected, falling back to plain text', [
                'pattern' => $pattern,
                'exception' => $e->getMessage(),
            ]);
        }

        $this->sendText($mobile, $message);
    }

    /*
    |--------------------------------------------------------------------------
    | چسباندن مقدارهای پترن
    |--------------------------------------------------------------------------
    |
    | ⚠️ جداکننده «,» است نه «;». هر دو نمونه‌ی رسمی خود آموت
    | (github.com/AmootSoft/AmootSMS) با کاما می‌چسبانند:
    |
    |     string.Join(",", PatternValues)        // C#
    |     "PatternValues=p1,p2"                  // PHP
    |
    | با جداکننده‌ی غلط، هر سه مقدار داخل متغیر اول می‌نشینند و بقیه
    | خالی می‌مانند. کد یک‌بارمصرف چون یک مقدار بیشتر ندارد این را لو
    | نمی‌داد؛ اولین پیامک یادآوری لو می‌داد.
    |
    | و چون کاما جداکننده است، خودِ مقدارها نباید کاما داشته باشند -
    | وگرنه یک نامِ «رضایی, محمد» پیام را به هم می‌ریزد. کامای لاتین
    | به کامای فارسی تبدیل می‌شود که در متن پیامک هم درست‌تر است.
    |
    */
    private function joinValues(array $values): string
    {
        return implode(',', array_map(
            fn ($value) => str_replace([',', ';'], '،', (string) $value),
            $values
        ));
    }

    /*
    |--------------------------------------------------------------------------
    | ارسال با پترن
    |--------------------------------------------------------------------------
    */
    private function sendWithPattern(string $mobile, int $patternId, string $values): void
    {
        [$token, $line] = $this->credentials();

        $response = Http::asForm()
            ->withHeaders(['Authorization' => $token])
            ->timeout(20)
            ->post('https://portal.amootsms.com/rest/SendWithPatternOWN', [
                'Mobile' => $mobile,
                'LineNumber' => $line,
                'PatternCodeID' => $patternId,
                'PatternValues' => $values,
            ]);

        $this->assertAccepted($response);
    }

    /*
    |--------------------------------------------------------------------------
    | ارسال متن ساده
    |--------------------------------------------------------------------------
    */
    private function sendText(string $mobile, string $message): void
    {
        [$token, $line] = $this->credentials();

        $response = Http::asForm()
            ->withHeaders(['Authorization' => $token])
            ->timeout(20)
            ->post('https://portal.amootsms.com/rest/SendSimple', [
                'Mobile' => $mobile,
                'LineNumber' => $line,
                'Message' => $message,
            ]);

        $this->assertAccepted($response);
    }

    private function credentials(): array
    {
        $token = config('services.amoot.token');
        $line = config('services.amoot.line_number');

        if (! $token || ! $line) {
            throw new RuntimeException('تنظیمات پیامک آموت کامل نشده است.');
        }

        return [$token, $line];
    }

    /*
    | آموت گاهی با کد ۲۰۰ ولی Status=false پاسخ می‌دهد، پس صرفِ
    | successful() بودن پاسخ کافی نیست.
    */
    private function assertAccepted($response): void
    {
        if (! $response->successful()) {
            throw new RuntimeException('ارسال پیامک ناموفق بود.');
        }

        $json = $response->json();

        if (
            is_array($json)
            && array_key_exists('Status', $json)
            && in_array($json['Status'], [false, 0, '0', 'false', 'False'], true)
        ) {
            throw new RuntimeException('سامانه پیامکی ارسال را تأیید نکرد.');
        }
    }
}
