@extends('layouts.app') @section('title','تماس با ما') @section('content')<div class="max-w-3xl mx-auto px-4 py-12"><div class="card p-8"><h1 class="text-3xl font-black">تماس با ما</h1><p class="text-sm text-gray-500 mt-2">اگر سوالی دارید یا پیامی برای ما ارسال می‌کنید، حتماً از طریق همان ایمیلی که وارد می‌کنید پاسخ شما را خواهیم داد.</p><form method="POST" action="{{ route('contact.store') }}" class="mt-6 space-y-4" data-gate>@csrf{{--
    تله‌ی ربات.

    این فیلد از چشم پنهان است و آدم هرگز پرش نمی‌کند. ربات فرم را از
    روی HTML پر می‌کند و همین لوش می‌دهد.

    - required نیست، وگرنه دروازه‌ی دکمه هرگز باز نمی‌شد
    - tabindex=-1 تا با Tab هم بهش نرسیم
    - aria-hidden تا صفحه‌خوان نخواندش
    - autocomplete=off تا مرورگر خودش پرش نکند

    opened_at زمان باز شدن فرم است، رمزگذاری‌شده تا دست‌کاری نشود.
    ارسالِ کمتر از سه ثانیه یعنی آدمی پشتش نیست.
--}}<div class="hp-field" aria-hidden="true"><label for="website">وب‌سایت</label><input id="website" type="text" name="website" value="" tabindex="-1" autocomplete="off"></div><input type="hidden" name="opened_at" value="{{ encrypt(time()) }}"><input name="name" value="{{ old('name') }}" class="w-full rounded-lg border" placeholder="نام و نام خانوادگی" required maxlength="255"><input name="email" type="email" value="{{ old('email') }}" class="w-full rounded-lg border" placeholder="ایمیل" required><input name="phone" value="{{ old('phone') }}" maxlength="15" inputmode="numeric" pattern="[0-9]*" data-digits-only class="w-full rounded-lg border" placeholder="تلفن"><input name="subject" value="{{ old('subject') }}" class="w-full rounded-lg border" placeholder="موضوع"><textarea name="message" rows="6" class="w-full rounded-lg border" placeholder="پیام شما" required maxlength="5000">{{ old('message') }}</textarea><button class="btn-primary" data-gate-submit>ارسال پیام</button></form></div></div>@endsection
